"""
Hospital Management System
A Flask-based application for managing patients, doctors, appointments, and medical records.
"""

from flask import Flask, render_template, request, redirect, url_for, flash, session, abort
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import or_
from datetime import datetime, timedelta
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-change-in-production'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///hospital.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# ==================== MODELS ====================

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # admin, doctor, patient
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100))
    phone = db.Column(db.String(15))
    # For patients
    age = db.Column(db.Integer)
    gender = db.Column(db.String(10))
    blood_group = db.Column(db.String(5))
    address = db.Column(db.Text)
    registration_date = db.Column(db.DateTime, default=datetime.utcnow)
    # For doctors
    specialization = db.Column(db.String(100))
    qualification = db.Column(db.String(200))
    experience = db.Column(db.Integer)
    consultation_fee = db.Column(db.Float)
    # Relationships
    appointments_as_patient = db.relationship('Appointment', foreign_keys='Appointment.patient_id', backref='patient', lazy=True)
    appointments_as_doctor = db.relationship('Appointment', foreign_keys='Appointment.doctor_id', backref='doctor', lazy=True)
    medical_records_as_patient = db.relationship('MedicalRecord', foreign_keys='MedicalRecord.patient_id', backref='patient', lazy=True)
    medical_records_as_doctor = db.relationship('MedicalRecord', foreign_keys='MedicalRecord.doctor_id', backref='doctor', lazy=True)
    availability_slots = db.relationship('DoctorAvailability', backref='doctor', lazy=True, cascade='all, delete-orphan')

class Appointment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    appointment_date = db.Column(db.DateTime, nullable=False)
    department = db.Column(db.String(100))
    status = db.Column(db.String(20), default='scheduled')  # scheduled, completed, cancelled
    reason = db.Column(db.Text)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class MedicalRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    visit_no = db.Column(db.Integer)
    visit_type = db.Column(db.String(50))  # In-person, Telemedicine
    tests_done = db.Column(db.Text)
    diagnosis = db.Column(db.Text, nullable=False)
    prescription = db.Column(db.Text)
    medicines = db.Column(db.Text)
    notes = db.Column(db.Text)
    record_date = db.Column(db.DateTime, default=datetime.utcnow)

class DoctorAvailability(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    doctor_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    is_available = db.Column(db.Boolean, default=True)

# ==================== HELPER FUNCTIONS ====================

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please login to access this page', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def role_required(roles):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_id' not in session:
                flash('Please login to access this page', 'warning')
                return redirect(url_for('login'))
            if session.get('role') not in roles:
                flash('You do not have permission to access this page', 'danger')
                return redirect(url_for('dashboard'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def clear_all_data_except_admin():
    """Clear all data except admin users - programmatic function"""
    with app.app_context():
        try:
            # Delete all appointments
            Appointment.query.delete()
            
            # Delete all medical records
            MedicalRecord.query.delete()
            
            # Delete all doctor availability slots
            DoctorAvailability.query.delete()
            
            # Delete all users except admins
            non_admin_users = User.query.filter(User.role != 'admin').all()
            for user in non_admin_users:
                db.session.delete(user)
            
            db.session.commit()
            print(f"Successfully purged all data. Deleted {len(non_admin_users)} non-admin users.")
            print("All appointments, medical records, and availability slots have been deleted.")
            print("Only admin users remain in the database.")
            return True
        except Exception as e:
            db.session.rollback()
            print(f"Error purging data: {str(e)}")
            return False


def init_db():
    with app.app_context():
        db.create_all()
        # Create only the admin user on first run
        if not User.query.filter_by(username='admin').first():
            admin = User(
                username='admin',
                password='admin123',  # TODO: change this in production!
                role='admin',
                name='Administrator',
                email='admin@hospital.com'
            )
            db.session.add(admin)
            db.session.commit()


        
        

# ==================== ROUTES ====================

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username, password=password).first()
        if user:
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            session['name'] = user.name
            flash(f'Welcome back, {user.name}!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        role = 'patient'  # Default role for registration
        
        # Patient specific fields
        age = request.form.get('age')
        gender = request.form.get('gender')
        blood_group = request.form.get('blood_group')
        address = request.form.get('address')
        
        if User.query.filter_by(username=username).first():
            flash('Username already exists!', 'danger')
            return render_template('signup.html')
        
        new_user = User(username=username, password=password, role=role, name=name,
                       email=email, phone=phone, age=age, gender=gender,
                       blood_group=blood_group, address=address)
        db.session.add(new_user)
        db.session.commit()
        
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    
    return render_template('signup.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    role = session.get('role')
    user = User.query.get(session['user_id'])
    
    if role == 'admin':
        return render_template('admin_dashboard.html', 
                             total_patients=User.query.filter_by(role='patient').count(),
                             total_doctors=User.query.filter_by(role='doctor').count(),
                             total_appointments=Appointment.query.count(),
                             total_medical_records=MedicalRecord.query.count(),
                             patients=User.query.filter_by(role='patient').limit(5).all(),
                             doctors=User.query.filter_by(role='doctor').limit(5).all(),
                             appointments=Appointment.query.order_by(Appointment.appointment_date.desc()).limit(10).all(),
                             medical_records=MedicalRecord.query.order_by(MedicalRecord.record_date.desc()).limit(10).all())
    
    elif role == 'doctor':
        today = datetime.now().date()
        return render_template('doctor_dashboard.html',
                             user=user,
                             upcoming_appointments=Appointment.query.filter_by(doctor_id=user.id).filter(
                                 Appointment.appointment_date >= datetime.now()).filter(
                                 Appointment.status != 'completed').filter(
                                 Appointment.status != 'cancelled').order_by(Appointment.appointment_date).limit(10).all(),
                             registered_patients=User.query.filter_by(role='patient').count(),
                             availability_slots=DoctorAvailability.query.filter_by(doctor_id=user.id).filter(
                                 DoctorAvailability.date >= today).order_by(DoctorAvailability.date).limit(7).all())
    
    elif role == 'patient':
        today = datetime.now().date()
        doctors = User.query.filter_by(role='doctor').all()
        # Load availability slots for each doctor
        for doctor in doctors:
            doctor.availability_slots = DoctorAvailability.query.filter_by(doctor_id=doctor.id).filter(
                DoctorAvailability.date >= today).filter_by(is_available=True).order_by(
                DoctorAvailability.date).limit(3).all()
        
        # Get unique specializations
        specializations = set()
        for doctor in doctors:
            if doctor.specialization:
                specializations.add(doctor.specialization)
        specializations = sorted(list(specializations))[:6]
        
        return render_template('patient_dashboard.html',
                             user=user,
                             upcoming_appointments=Appointment.query.filter_by(patient_id=user.id).filter(
                                 Appointment.appointment_date >= datetime.now()).order_by(Appointment.appointment_date).limit(5).all(),
                             medical_records=MedicalRecord.query.filter_by(patient_id=user.id).order_by(
                                 MedicalRecord.record_date.desc()).limit(5).all(),
                             doctors=doctors,
                             specializations=specializations)
    
    return redirect(url_for('login'))

# ==================== ADMIN ROUTES ====================

@app.route('/admin/doctors/add', methods=['GET', 'POST'])
@role_required(['admin'])
def admin_add_doctor():
    if request.method == 'POST':
        import secrets
        import string
        
        # Check if auto-generate is requested
        auto_generate = request.form.get('auto_generate') == 'on'
        
        if auto_generate:
            # Auto-generate username from name
            name = request.form.get('name', '').strip()
            base_username = ''.join(c.lower() for c in name if c.isalnum())[:8]
            if not base_username:
                base_username = 'doctor'
            
            # Ensure username is unique
            username = base_username
            counter = 1
            while User.query.filter_by(username=username).first():
                username = f"{base_username}{counter}"
                counter += 1
            
            # Auto-generate password (8 characters: letters, digits, and symbols)
            password_chars = string.ascii_letters + string.digits
            password = ''.join(secrets.choice(password_chars) for _ in range(8))
        else:
            username = request.form.get('username')
            password = request.form.get('password')
        
        # Check if username already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists! Please choose a different one.', 'danger')
            return redirect(url_for('admin_add_doctor'))
        
        doctor = User(
            username=username,
            password=password,
            role='doctor',
            name=request.form.get('name'),
            email=request.form.get('email'),
            phone=request.form.get('phone'),
            specialization=request.form.get('specialization'),
            qualification=request.form.get('qualification'),
            experience=request.form.get('experience'),
            consultation_fee=request.form.get('consultation_fee')
        )
        db.session.add(doctor)
        db.session.commit()
        
        # Store credentials in session to display them
        session['new_doctor_credentials'] = {
            'name': doctor.name,
            'username': username,
            'password': password
        }
        
        flash('Doctor added successfully! Credentials are shown below.', 'success')
        return redirect(url_for('admin_add_doctor'))
    
    # Get credentials from session if available
    credentials = session.pop('new_doctor_credentials', None)
    return render_template('admin_add_doctor.html', credentials=credentials)

@app.route('/admin/patients')
@role_required(['admin'])
def admin_patients():
    search = request.args.get('search', '')
    department = request.args.get('department', '')
    
    query = User.query.filter_by(role='patient')
    if search:
        query = query.filter(User.name.contains(search))
    
    patients = query.all()
    return render_template('admin_patients.html', patients=patients)

@app.route('/admin/doctors')
@role_required(['admin'])
def admin_doctors():
    search = request.args.get('search', '')
    
    query = User.query.filter_by(role='doctor')
    if search:
        query = query.filter(
            or_(
                User.name.contains(search),
                User.specialization.contains(search)
            )
        )
    
    doctors = query.all()
    return render_template('admin_doctors.html', doctors=doctors)

@app.route('/admin/purge-data', methods=['GET', 'POST'])
@role_required(['admin'])
def purge_data():
    """Purge all data except admin users"""
    if request.method == 'POST':
        try:
            # Delete all appointments
            Appointment.query.delete()
            
            # Delete all medical records
            MedicalRecord.query.delete()
            
            # Delete all doctor availability slots
            DoctorAvailability.query.delete()
            
            # Delete all users except admins
            User.query.filter(User.role != 'admin').delete()
            
            db.session.commit()
            flash('All data has been purged successfully. Only admin users remain.', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error purging data: {str(e)}', 'danger')
        
        return redirect(url_for('dashboard'))
    
    # GET request - show confirmation page
    stats = {
        'patients': User.query.filter_by(role='patient').count(),
        'doctors': User.query.filter_by(role='doctor').count(),
        'appointments': Appointment.query.count(),
        'medical_records': MedicalRecord.query.count(),
        'availability_slots': DoctorAvailability.query.count()
    }
    return render_template('admin_purge_confirm.html', stats=stats)

# ==================== DOCTOR ROUTES ====================

@app.route('/doctor/patients')
@role_required(['doctor'])
def doctor_patients():
    doctor_id = session['user_id']
    # Get patients who have appointments with this doctor
    patient_ids = db.session.query(Appointment.patient_id).filter_by(doctor_id=doctor_id).distinct().all()
    patient_ids = [p[0] for p in patient_ids]
    patients = User.query.filter(User.id.in_(patient_ids)).all()
    
    return render_template('doctor_patients.html', patients=patients)

@app.route('/doctor/patient/history/<int:patient_id>')
@role_required(['doctor', 'admin'])
def patient_history(patient_id):
    patient = User.query.get_or_404(patient_id)
    records = MedicalRecord.query.filter_by(patient_id=patient_id).order_by(MedicalRecord.record_date.desc()).all()
    
    return render_template('patient_history.html', patient=patient, records=records)

@app.route('/doctor/patient/update/<int:patient_id>', methods=['GET', 'POST'])
@role_required(['doctor'])
def update_patient_history(patient_id):
    patient = User.query.get_or_404(patient_id)
    
    if request.method == 'POST':
        record = MedicalRecord(
            patient_id=patient_id,
            doctor_id=session['user_id'],
            visit_no=request.form.get('visit_no'),
            visit_type=request.form.get('visit_type'),
            tests_done=request.form.get('tests_done'),
            diagnosis=request.form.get('diagnosis'),
            prescription=request.form.get('prescription'),
            medicines=request.form.get('medicines'),
            notes=request.form.get('notes')
        )
        db.session.add(record)
        db.session.commit()
        flash('Patient history updated successfully!', 'success')
        return redirect(url_for('patient_history', patient_id=patient_id))
    
    visit_count = MedicalRecord.query.filter_by(patient_id=patient_id).count() + 1
    return render_template('update_patient_history.html', patient=patient, visit_count=visit_count)

@app.route('/doctor/availability', methods=['GET', 'POST'])
@role_required(['doctor'])
def doctor_availability():
    doctor_id = session.get('user_id')
    if not doctor_id:
        # Always return something
        flash('Not signed in.', 'danger')
        return redirect(url_for('login'))

    today = datetime.now().date()
    today_str = today.strftime('%Y-%m-%d')

    # Preload slots so we can re-render the form on any failure path
    slots = (DoctorAvailability.query
             .filter_by(doctor_id=doctor_id)
             .filter(DoctorAvailability.date >= today)
             .order_by(DoctorAvailability.date)
             .all())

    if request.method == 'POST':
        date_str = request.form.get('date')
        start_time_str = request.form.get('start_time')
        end_time_str = request.form.get('end_time')

        # Validate presence
        if not date_str or not start_time_str or not end_time_str:
            flash('Please fill all fields.', 'warning')
            return render_template('doctor_availability.html',
                                   slots=slots, today_str=today_str)

        # Validate formats
        try:
            date = datetime.strptime(date_str, '%Y-%m-%d').date()
            start_time = datetime.strptime(start_time_str, '%H:%M').time()
            end_time = datetime.strptime(end_time_str, '%H:%M').time()
        except ValueError:
            flash('Invalid date/time format.', 'danger')
            return render_template('doctor_availability.html',
                                   slots=slots, today_str=today_str)

        # Logical validations
        if end_time <= start_time:
            flash('End time must be after start time.', 'warning')
            return render_template('doctor_availability.html',
                                   slots=slots, today_str=today_str)
        if date < today:
            flash('Date must be today or later.', 'warning')
            return render_template('doctor_availability.html',
                                   slots=slots, today_str=today_str)

        # Save
        availability = DoctorAvailability(
            doctor_id=doctor_id,
            date=date,
            start_time=start_time,
            end_time=end_time
        )
        db.session.add(availability)
        db.session.commit()
        flash('Availability added successfully!', 'success')
        return redirect(url_for('doctor_availability'))

    # GET request
    return render_template('doctor_availability.html',
                           slots=slots, today_str=today_str)




# ==================== PATIENT ROUTES ====================

@app.route('/patient/profile')
@login_required
def patient_profile():
    user = User.query.get(session['user_id'])
    return render_template('patient_profile.html', user=user)

@app.route('/patient/appointments')
@login_required
def patient_appointments():
    patient_id = session['user_id']
    appointments = Appointment.query.filter_by(patient_id=patient_id).order_by(Appointment.appointment_date.desc()).all()
    return render_template('patient_appointments.html', appointments=appointments)

@app.route('/patient/book-appointment', methods=['GET', 'POST'])
@role_required(['patient'])
def book_appointment():
    if request.method == 'POST':
        appointment = Appointment(
            patient_id=session['user_id'],
            doctor_id=request.form.get('doctor_id'),
            appointment_date=datetime.strptime(request.form.get('appointment_date'), '%Y-%m-%dT%H:%M'),
            reason=request.form.get('reason')
        )
        db.session.add(appointment)
        db.session.commit()
        flash('Appointment booked successfully!', 'success')
        return redirect(url_for('dashboard'))
    
    doctors = User.query.filter_by(role='doctor').all()
    now_str = datetime.now().strftime('%Y-%m-%dT%H:%M')
    return render_template('book_appointments.html', doctors=doctors, now_str=now_str)

@app.route('/patient/doctors')
@role_required(['patient'])
def view_doctors():
    search = request.args.get('search', '')
    query = User.query.filter_by(role='doctor')
    
    if search:
        query = query.filter(User.specialization.contains(search))
    
    doctors = query.all()
    return render_template('view_doctors.html', doctors=doctors)

@app.route('/patient/doctor/<int:doctor_id>/availability')
@login_required
def doctor_availability_view(doctor_id):
    doctor = User.query.get_or_404(doctor_id)
    today = datetime.now().date()
    slots = DoctorAvailability.query.filter_by(doctor_id=doctor_id).filter(
        DoctorAvailability.date >= today).order_by(DoctorAvailability.date).limit(7).all()
    
    return render_template('doctor_availability_view.html', doctor=doctor, slots=slots)

# ==================== APPOINTMENT ROUTES ====================

@app.route('/appointments')
@login_required
def appointments():
    all_appointments = Appointment.query.order_by(Appointment.appointment_date.desc()).all()
    return render_template('appointments.html', appointments=all_appointments)

@app.route('/appointments/add', methods=['GET', 'POST'])
@login_required
def add_appointment():
    if request.method == 'POST':
        appointment = Appointment(
            patient_id=request.form.get('patient_id'),
            doctor_id=request.form.get('doctor_id'),
            appointment_date=datetime.strptime(request.form.get('appointment_date'), '%Y-%m-%dT%H:%M'),
            reason=request.form.get('reason'),
            notes=request.form.get('notes')
        )
        db.session.add(appointment)
        db.session.commit()
        flash('Appointment scheduled successfully!', 'success')
        return redirect(url_for('appointments'))
    
    patients = User.query.filter_by(role='patient').all()
    doctors = User.query.filter_by(role='doctor').all()
    return render_template('appointment_form.html', appointment=None, patients=patients, doctors=doctors)

@app.route('/appointments/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_appointment(id):
    appointment = Appointment.query.get_or_404(id)
    
    if request.method == 'POST':
        appointment.patient_id = request.form.get('patient_id')
        appointment.doctor_id = request.form.get('doctor_id')
        appointment.appointment_date = datetime.strptime(request.form.get('appointment_date'), '%Y-%m-%dT%H:%M')
        appointment.status = request.form.get('status')
        appointment.reason = request.form.get('reason')
        appointment.notes = request.form.get('notes')
        db.session.commit()
        flash('Appointment updated successfully!', 'success')
        return redirect(url_for('appointments'))
    
    patients = User.query.filter_by(role='patient').all()
    doctors = User.query.filter_by(role='doctor').all()
    return render_template('appointment_form.html', appointment=appointment, patients=patients, doctors=doctors)

@app.route('/appointments/delete/<int:id>')
@login_required
def delete_appointment(id):
    appointment = Appointment.query.get_or_404(id)
    db.session.delete(appointment)
    db.session.commit()
    flash('Appointment deleted successfully!', 'success')
    return redirect(url_for('appointments'))

@app.route('/appointments/complete/<int:id>')
@login_required
def complete_appointment(id):
    appointment = Appointment.query.get_or_404(id)
    # Check if user is the doctor for this appointment or admin
    if session.get('role') == 'admin' or (session.get('role') == 'doctor' and appointment.doctor_id == session.get('user_id')):
        appointment.status = 'completed'
        db.session.commit()
        flash('Appointment marked as completed!', 'success')
    else:
        flash('You do not have permission to complete this appointment.', 'danger')
    return redirect(url_for('dashboard'))

@app.route('/appointments/cancel/<int:id>')
@login_required
def cancel_appointment(id):
    appointment = Appointment.query.get_or_404(id)
    # Check if user is the doctor, patient, or admin for this appointment
    user_id = session.get('user_id')
    if session.get('role') == 'admin' or appointment.doctor_id == user_id or appointment.patient_id == user_id:
        appointment.status = 'cancelled'
        db.session.commit()
        flash('Appointment cancelled successfully!', 'success')
    else:
        flash('You do not have permission to cancel this appointment.', 'danger')
    return redirect(url_for('dashboard'))

# ==================== MEDICAL RECORD ROUTES ====================

@app.route('/medical-records')
@login_required
def medical_records():
    all_records = MedicalRecord.query.order_by(MedicalRecord.record_date.desc()).all()
    return render_template('medical_records.html', records=all_records)

@app.route('/medical-records/add', methods=['GET', 'POST'])
@login_required
def add_medical_record():
    if request.method == 'POST':
        # Auto-set doctor_id if user is a doctor
        doctor_id = request.form.get('doctor_id') or (session.get('user_id') if session.get('role') == 'doctor' else None)
        
        record = MedicalRecord(
            patient_id=request.form.get('patient_id'),
            doctor_id=doctor_id,
            visit_no=request.form.get('visit_no'),
            visit_type=request.form.get('visit_type'),
            tests_done=request.form.get('tests_done'),
            diagnosis=request.form.get('diagnosis'),
            prescription=request.form.get('prescription'),
            medicines=request.form.get('medicines'),
            notes=request.form.get('notes')
        )
        db.session.add(record)
        db.session.commit()
        flash('Medical record added successfully!', 'success')
        return redirect(url_for('medical_records'))
    
    patients = User.query.filter_by(role='patient').all()
    doctors = User.query.filter_by(role='doctor').all()
    # If current user is a doctor, pre-select them
    current_doctor_id = session.get('user_id') if session.get('role') == 'doctor' else None
    return render_template('medical_record_form.html', record=None, patients=patients, doctors=doctors, current_doctor_id=current_doctor_id)

@app.route('/medical-records/view/<int:id>')
@login_required
def view_medical_record(id):
    record = MedicalRecord.query.get_or_404(id)
    return render_template('medical_record_view.html', record=record)

# ==================== DOCTOR ROUTES ====================

@app.route('/doctors')
@login_required
def doctors():
    all_doctors = User.query.filter_by(role='doctor').all()
    return render_template('doctors.html', doctors=all_doctors)

@app.route('/doctors/add', methods=['GET', 'POST'])
@login_required
def add_doctor():
    if request.method == 'POST':
        doctor = User(
            name=request.form.get('name'),
            specialization=request.form.get('specialization'),
            phone=request.form.get('phone'),
            email=request.form.get('email'),
            qualification=request.form.get('qualification'),
            experience=request.form.get('experience'),
            consultation_fee=request.form.get('consultation_fee'),
            role='doctor',
            username=request.form.get('username') or request.form.get('email'),
            password=generate_password_hash(request.form.get('password') or 'password123')
        )
        db.session.add(doctor)
        db.session.commit()
        flash('Doctor added successfully!', 'success')
        return redirect(url_for('doctors'))
    
    return render_template('doctor_form.html', doctor=None)

@app.route('/doctors/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_doctor(id):
    doctor = User.query.get_or_404(id)
    if doctor.role != 'doctor':
        flash('Invalid doctor ID', 'danger')
        return redirect(url_for('doctors'))
    
    if request.method == 'POST':
        doctor.name = request.form.get('name')
        doctor.specialization = request.form.get('specialization')
        doctor.phone = request.form.get('phone')
        doctor.email = request.form.get('email')
        doctor.qualification = request.form.get('qualification')
        doctor.experience = request.form.get('experience')
        doctor.consultation_fee = request.form.get('consultation_fee')
        if request.form.get('password'):
            doctor.password = generate_password_hash(request.form.get('password'))
        db.session.commit()
        flash('Doctor updated successfully!', 'success')
        return redirect(url_for('doctors'))
    
    return render_template('doctor_form.html', doctor=doctor)

@app.route('/doctors/delete/<int:id>')
@login_required
def delete_doctor(id):
    doctor = User.query.get_or_404(id)
    if doctor.role != 'doctor':
        flash('Invalid doctor ID', 'danger')
        return redirect(url_for('doctors'))
    db.session.delete(doctor)
    db.session.commit()
    flash('Doctor deleted successfully!', 'success')
    return redirect(url_for('doctors'))

# ==================== MAIN ====================

if __name__ == '__main__':
    import sys
    
    # Check if purge command is passed
    if len(sys.argv) > 1 and sys.argv[1] == '--purge':
        print("Purging all data except admin users...")
        clear_all_data_except_admin()
        sys.exit(0)
    
    init_db()
    app.run(debug=True)

# ==================== HELPER FUNCTIONS ====================

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please login to access this page', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def init_db():
    with app.app_context():
        db.create_all()
        # Create default admin user if not exists
        if not User.query.filter_by(username='admin').first():
            admin = User(username='admin', password='admin123', role='admin', name='Administrator')
            db.session.add(admin)
            db.session.commit()
            print("Default admin created: username='admin', password='admin123'")

# ==================== ROUTES ====================

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username, password=password).first()
        if user:
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            session['name'] = user.name
            flash(f'Welcome back, {user.name}!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials', 'danger')
    
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        name = request.form.get('name')
        role = request.form.get('role', 'receptionist')
        
        # Validation
        if password != confirm_password:
            flash('Passwords do not match!', 'danger')
            return render_template('signup.html')
        
        # Check if username already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists!', 'danger')
            return render_template('signup.html')
        
        # Create new user
        new_user = User(username=username, password=password, role=role, name=name)
        db.session.add(new_user)
        db.session.commit()
        
        flash('Account created successfully! Please login.', 'success')
        return redirect(url_for('login'))
    
    return render_template('signup.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    stats = {
        'total_patients': Patient.query.count(),
        'total_doctors': Doctor.query.count(),
        'total_appointments': Appointment.query.count(),
        'today_appointments': Appointment.query.filter(
            db.func.date(Appointment.appointment_date) == datetime.utcnow().date()
        ).count()
    }
    recent_appointments = Appointment.query.order_by(Appointment.appointment_date.desc()).limit(5).all()
    return render_template('dashboard.html', stats=stats, recent_appointments=recent_appointments)

# ==================== PATIENT ROUTES ====================

@app.route('/patients')
@login_required
def patients():
    all_patients = Patient.query.order_by(Patient.registration_date.desc()).all()
    return render_template('patients.html', patients=all_patients)

@app.route('/patients/add', methods=['GET', 'POST'])
@login_required
def add_patient():
    if request.method == 'POST':
        patient = Patient(
            name=request.form.get('name'),
            age=request.form.get('age'),
            gender=request.form.get('gender'),
            phone=request.form.get('phone'),
            email=request.form.get('email'),
            address=request.form.get('address'),
            blood_group=request.form.get('blood_group')
        )
        db.session.add(patient)
        db.session.commit()
        flash('Patient added successfully!', 'success')
        return redirect(url_for('patients'))
    
    return render_template('patient_form.html', patient=None)

@app.route('/patients/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_patient(id):
    patient = Patient.query.get_or_404(id)
    
    if request.method == 'POST':
        patient.name = request.form.get('name')
        patient.age = request.form.get('age')
        patient.gender = request.form.get('gender')
        patient.phone = request.form.get('phone')
        patient.email = request.form.get('email')
        patient.address = request.form.get('address')
        patient.blood_group = request.form.get('blood_group')
        db.session.commit()
        flash('Patient updated successfully!', 'success')
        return redirect(url_for('patients'))
    
    return render_template('patient_form.html', patient=patient)

@app.route('/patients/delete/<int:id>')
@login_required
def delete_patient(id):
    patient = Patient.query.get_or_404(id)
    db.session.delete(patient)
    db.session.commit()
    flash('Patient deleted successfully!', 'success')
    return redirect(url_for('patients'))

@app.route('/patients/view/<int:id>')
@login_required
def view_patient(id):
    patient = Patient.query.get_or_404(id)
    return render_template('patient_view.html', patient=patient)

# ==================== APPOINTMENT ROUTES ====================

@app.route('/appointments')
@login_required
def appointments():
    all_appointments = Appointment.query.order_by(Appointment.appointment_date.desc()).all()
    return render_template('appointments.html', appointments=all_appointments)

@app.route('/appointments/add', methods=['GET', 'POST'])
@login_required
def add_appointment():
    if request.method == 'POST':
        appointment = Appointment(
            patient_id=request.form.get('patient_id'),
            doctor_id=request.form.get('doctor_id'),
            appointment_date=datetime.strptime(request.form.get('appointment_date'), '%Y-%m-%dT%H:%M'),
            reason=request.form.get('reason'),
            notes=request.form.get('notes')
        )
        db.session.add(appointment)
        db.session.commit()
        flash('Appointment scheduled successfully!', 'success')
        return redirect(url_for('appointments'))
    
    patients = User.query.filter_by(role='patient').all()
    doctors = User.query.filter_by(role='doctor').all()
    return render_template('appointment_form.html', appointment=None, patients=patients, doctors=doctors)

@app.route('/appointments/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_appointment(id):
    appointment = Appointment.query.get_or_404(id)
    
    if request.method == 'POST':
        appointment.patient_id = request.form.get('patient_id')
        appointment.doctor_id = request.form.get('doctor_id')
        appointment.appointment_date = datetime.strptime(request.form.get('appointment_date'), '%Y-%m-%dT%H:%M')
        appointment.status = request.form.get('status')
        appointment.reason = request.form.get('reason')
        appointment.notes = request.form.get('notes')
        db.session.commit()
        flash('Appointment updated successfully!', 'success')
        return redirect(url_for('appointments'))
    
    patients = User.query.filter_by(role='patient').all()
    doctors = User.query.filter_by(role='doctor').all()
    return render_template('appointment_form.html', appointment=appointment, patients=patients, doctors=doctors)

@app.route('/appointments/delete/<int:id>')
@login_required
def delete_appointment(id):
    appointment = Appointment.query.get_or_404(id)
    db.session.delete(appointment)
    db.session.commit()
    flash('Appointment deleted successfully!', 'success')
    return redirect(url_for('appointments'))

@app.route('/appointments/complete/<int:id>')
@login_required
def complete_appointment(id):
    appointment = Appointment.query.get_or_404(id)
    # Check if user is the doctor for this appointment or admin
    if session.get('role') == 'admin' or (session.get('role') == 'doctor' and appointment.doctor_id == session.get('user_id')):
        appointment.status = 'completed'
        db.session.commit()
        flash('Appointment marked as completed!', 'success')
    else:
        flash('You do not have permission to complete this appointment.', 'danger')
    return redirect(url_for('dashboard'))

@app.route('/appointments/cancel/<int:id>')
@login_required
def cancel_appointment(id):
    appointment = Appointment.query.get_or_404(id)
    # Check if user is the doctor, patient, or admin for this appointment
    user_id = session.get('user_id')
    if session.get('role') == 'admin' or appointment.doctor_id == user_id or appointment.patient_id == user_id:
        appointment.status = 'cancelled'
        db.session.commit()
        flash('Appointment cancelled successfully!', 'success')
    else:
        flash('You do not have permission to cancel this appointment.', 'danger')
    return redirect(url_for('dashboard'))

# ==================== MEDICAL RECORD ROUTES ====================

@app.route('/medical-records')
@login_required
def medical_records():
    all_records = MedicalRecord.query.order_by(MedicalRecord.record_date.desc()).all()
    return render_template('medical_records.html', records=all_records)

@app.route('/medical-records/add', methods=['GET', 'POST'])
@login_required
def add_medical_record():
    if request.method == 'POST':
        # Auto-set doctor_id if user is a doctor
        doctor_id = request.form.get('doctor_id') or (session.get('user_id') if session.get('role') == 'doctor' else None)
        
        record = MedicalRecord(
            patient_id=request.form.get('patient_id'),
            doctor_id=doctor_id,
            visit_no=request.form.get('visit_no'),
            visit_type=request.form.get('visit_type'),
            tests_done=request.form.get('tests_done'),
            diagnosis=request.form.get('diagnosis'),
            prescription=request.form.get('prescription'),
            medicines=request.form.get('medicines'),
            notes=request.form.get('notes')
        )
        db.session.add(record)
        db.session.commit()
        flash('Medical record added successfully!', 'success')
        return redirect(url_for('medical_records'))
    
    patients = User.query.filter_by(role='patient').all()
    doctors = User.query.filter_by(role='doctor').all()
    # If current user is a doctor, pre-select them
    current_doctor_id = session.get('user_id') if session.get('role') == 'doctor' else None
    return render_template('medical_record_form.html', record=None, patients=patients, doctors=doctors, current_doctor_id=current_doctor_id)

@app.route('/medical-records/view/<int:id>')
@login_required
def view_medical_record(id):
    record = MedicalRecord.query.get_or_404(id)
    return render_template('medical_record_view.html', record=record)

# ==================== DOCTOR ROUTES ====================

@app.route('/doctors')
@login_required
def doctors():
    all_doctors = User.query.filter_by(role='doctor').all()
    return render_template('doctors.html', doctors=all_doctors)

@app.route('/doctors/add', methods=['GET', 'POST'])
@login_required
def add_doctor():
    if request.method == 'POST':
        doctor = User(
            name=request.form.get('name'),
            specialization=request.form.get('specialization'),
            phone=request.form.get('phone'),
            email=request.form.get('email'),
            qualification=request.form.get('qualification'),
            experience=request.form.get('experience'),
            consultation_fee=request.form.get('consultation_fee'),
            role='doctor',
            username=request.form.get('username') or request.form.get('email'),
            password=generate_password_hash(request.form.get('password') or 'password123')
        )
        db.session.add(doctor)
        db.session.commit()
        flash('Doctor added successfully!', 'success')
        return redirect(url_for('doctors'))
    
    return render_template('doctor_form.html', doctor=None)

@app.route('/doctors/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_doctor(id):
    doctor = User.query.get_or_404(id)
    if doctor.role != 'doctor':
        flash('Invalid doctor ID', 'danger')
        return redirect(url_for('doctors'))
    
    if request.method == 'POST':
        doctor.name = request.form.get('name')
        doctor.specialization = request.form.get('specialization')
        doctor.phone = request.form.get('phone')
        doctor.email = request.form.get('email')
        doctor.qualification = request.form.get('qualification')
        doctor.experience = request.form.get('experience')
        doctor.consultation_fee = request.form.get('consultation_fee')
        if request.form.get('password'):
            doctor.password = generate_password_hash(request.form.get('password'))
        db.session.commit()
        flash('Doctor updated successfully!', 'success')
        return redirect(url_for('doctors'))
    
    return render_template('doctor_form.html', doctor=doctor)

@app.route('/doctors/delete/<int:id>')
@login_required
def delete_doctor(id):
    doctor = User.query.get_or_404(id)
    if doctor.role != 'doctor':
        flash('Invalid doctor ID', 'danger')
        return redirect(url_for('doctors'))
    db.session.delete(doctor)
    db.session.commit()
    flash('Doctor deleted successfully!', 'success')
    return redirect(url_for('doctors'))

# ==================== MAIN ====================

if __name__ == '__main__':
    import sys
    
    # Check if purge command is passed
    if len(sys.argv) > 1 and sys.argv[1] == '--purge':
        print("Purging all data except admin users...")
        clear_all_data_except_admin()
        sys.exit(0)
    
    init_db()
    app.run(debug=True)